package pt.ulusofona.lp2.greatprogrammingjourney;

public class CrashAbyss extends Abyss {

    public static final int ID = 4;
    private static final String NAME = "Crash de Memória";
    private static final String IMAGE_NAME = "crash.png"; // tem de existir em /images do jar

    public CrashAbyss(int position) {
        super(ID, NAME, position);
    }

    @Override
    public void applyEffect(Programmer programmer, int diceValue, int previousPosition) {
        if (programmer == null) {
            return;
        }
        programmer.setPosition(1); // Recuar para a posição 1
    }

    @Override
    public boolean forcesRepeatTurn() {
        // Este abismo obriga o jogador a repetir a vez
        return false;
    }

    @Override
    public String getImageName() {
        return IMAGE_NAME;
    }
}
